/**
 * 
 */
/**
 * 
 */
module BlackScholes {
	
	requires java.desktop;
}