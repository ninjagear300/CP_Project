package finance;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadLocalRandom;

public class MonteCarloBlackScholesParallel {

    /**
     * Perform Monte Carlo simulation in parallel using Futures to collect results.
     * This version is more efficient by avoiding shared accumulators and in-loop casting.
     *
     * @param S0      initial stock price
     * @param K       strike price
     * @param r       risk-free rate
     * @param sigma   volatility
     * @param T       time to maturity
     * @param paths   total number of simulation paths
     * @param threads number of worker threads
     * @return discounted call price estimate
     */
    public static double compute(double S0,
                                 double K,
                                 double r,
                                 double sigma,
                                 double T,
                                 long paths,
                                 int threads) throws InterruptedException, ExecutionException {
        ExecutorService exec = Executors.newFixedThreadPool(threads);
        List<Callable<Double>> tasks = new ArrayList<>(threads);
        long batch = paths / threads;

        // Pre-calculate invariant values to reduce redundant computation inside the loop
        final double drift = (r - 0.5 * sigma * sigma) * T;
        final double diffusion = sigma * Math.sqrt(T);

        for (int t = 0; t < threads; t++) {
            final long start = t * batch;
            // Ensure the last thread handles any remaining paths
            final long end = (t == threads - 1) ? paths : start + batch;

            Callable<Double> task = () -> {
                double localSumOfPayoffs = 0.0;
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                for (long i = start; i < end; i++) {
                    double z = rnd.nextGaussian();
                    double ST = S0 * Math.exp(drift + diffusion * z);
                    double payoff = Math.max(ST - K, 0.0);
                    localSumOfPayoffs += payoff;
                }
                return localSumOfPayoffs;
            };
            tasks.add(task);
        }

        // Execute all tasks and wait for them to complete
        List<Future<Double>> futures = exec.invokeAll(tasks);

        double totalPayoff = 0.0;
        // Sum the results from all threads
        for (Future<Double> future : futures) {
            totalPayoff += future.get();
        }

        exec.shutdown();

        // Calculate the average payoff and discount it
        double avgPayoff = totalPayoff / paths;
        return Math.exp(-r * T) * avgPayoff;
    }

    /**
     * Wraps compute(...) with timing and prints result.
     *
     * @return elapsed nanoseconds
     */
    public static long runAndTime(double S0,
                                  double K,
                                  double r,
                                  double sigma,
                                  double T,
                                  long paths,
                                  int threads) {
        try {
            long t0 = System.nanoTime();
            double price = compute(S0, K, r, sigma, T, paths, threads);
            long t1 = System.nanoTime();
            System.out.printf("Parallel (Future<Double>, %d threads) price: %.6f (%.2f ms)%n",
                              threads, price, (t1 - t0) / 1e6);
            return t1 - t0;
        } catch (InterruptedException | ExecutionException ex) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Computation failed", ex);
        }
    }
}