package finance;

import java.util.concurrent.ThreadLocalRandom;

public class MonteCarloBlackScholesSequential {
    /** 
     * Simulate 'paths' random payoffs and return discounted average. 
     */
    public static double compute(double S0, double K, double r,
                                 double sigma, double T, long paths) {
        double sum = 0.0;
        for (long i = 0; i < paths; i++) {
            double z  = ThreadLocalRandom.current().nextGaussian();
            double ST = S0 * Math.exp((r - 0.5 * sigma * sigma) * T
                        + sigma * Math.sqrt(T) * z);
            sum += Math.max(ST - K, 0.0);
        }
        return Math.exp(-r * T) * (sum / paths);
    }

    /** Run compute() and print timing. Returns elapsed nanoseconds. */
    public static long runAndTime(double S0, double K, double r,
                                  double sigma, double T, long paths) {
        long t0 = System.nanoTime();
        double price = compute(S0, K, r, sigma, T, paths);
        long t1 = System.nanoTime();
        System.out.printf("Sequential price: %.6f (%.2f ms)%n",
                          price, (t1 - t0) / 1e6);
        return t1 - t0;
    }
}

