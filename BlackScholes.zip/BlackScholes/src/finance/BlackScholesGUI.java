package finance;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class BlackScholesGUI extends JFrame {
    private final JTextField s0Field      = new JTextField("100");
    private final JTextField kField       = new JTextField("100");
    private final JTextField rField       = new JTextField("0.05");
    private final JTextField sigmaField   = new JTextField("0.2");
    private final JTextField tField       = new JTextField("1");
    private final JTextField pathsField   = new JTextField("1000000");
    private final JTextField threadsField = new JTextField("4");
    private final JTextArea  output       = new JTextArea(8, 40);

    public BlackScholesGUI() {
        super("Black-Scholes Monte Carlo Demo");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel in = new JPanel(new GridLayout(0, 2, 5, 5));
        in.add(new JLabel("S₀:"));       in.add(s0Field);
        in.add(new JLabel("K:"));            in.add(kField);
        in.add(new JLabel("r:"));            in.add(rField);
        in.add(new JLabel("\u03C3:"));       in.add(sigmaField);
        in.add(new JLabel("T:"));            in.add(tField);
        in.add(new JLabel("Paths:"));        in.add(pathsField);
        in.add(new JLabel("Threads:"));      in.add(threadsField);

        JButton runBtn = new JButton("Run");
        runBtn.addActionListener(this::onRun);

        output.setEditable(false);
        JScrollPane scroll = new JScrollPane(output);

        getContentPane().add(in, BorderLayout.NORTH);
        getContentPane().add(runBtn, BorderLayout.CENTER);
        getContentPane().add(scroll, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void onRun(ActionEvent __) {
        output.setText("");
        try {
            double S0    = Double.parseDouble(s0Field.getText());
            double K     = Double.parseDouble(kField.getText());
            double r     = Double.parseDouble(rField.getText());
            double sigma = Double.parseDouble(sigmaField.getText());
            double T     = Double.parseDouble(tField.getText());
            long paths   = Long.parseLong(pathsField.getText());
            int threads  = Integer.parseInt(threadsField.getText());

         // Parallel run
            long parStart = System.nanoTime();
            double parPrice = MonteCarloBlackScholesParallel.compute(
                    S0, K, r, sigma, T, paths, threads);
            long parEnd = System.nanoTime();
            double parTime = (parEnd - parStart) / 1e6;
            output.append(String.format(
                    "sequential price: %.6f, time: %.2f ms%n",
                    parPrice, parTime));
            
            // Sequential run
            long seqStart = System.nanoTime();
            double seqPrice = MonteCarloBlackScholesSequential.compute(
                    S0, K, r, sigma, T, paths);
            long seqEnd = System.nanoTime();
            double seqTime = (seqEnd - seqStart) / 1e6;
            output.append(String.format(
                    "parallel price: %.6f, time: %.2f ms%n",
                    seqPrice, seqTime));

            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error: " + ex.getMessage(),
                    "Input error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(BlackScholesGUI::new);
    }
}
